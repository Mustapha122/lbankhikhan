<?php
error_reporting(0);

//Change Your Email Here 
$send = "Put Your Email Here";
	 
?>